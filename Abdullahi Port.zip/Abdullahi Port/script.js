// changin navbar styles

window.addEventListener('scroll', () =>{
    document.querySelector('nav').classList.toggle
    ('window-scroll',window.scrollY > 100)

})

//show & hide faq answers

const faqs = document.querySelectorAll('.faq')
faqs.forEach(faq =>{
    faq.addEventListener('click',() =>{
        faq.classList.toggle('open');

        //--------- change icon------

        const icon = faq.querySelector('.faq_icon i');
        if(icon.className === 'fa-solid fa-plus'){
            icon.className = 'fa-solid fa-minus'
        }else {
            icon.className = 'fa-solid fa-plus'
        }
    })
})


//show/hide nav menu

const menu = document.querySelector('.nav_menu');
const menu_btn = document.querySelector('#open_menu_btn');
const close_btn = document.querySelector('#close_menu_btn');

menu_btn.addEventListener('click',() => {
    menu.style.display = 'flex';
    close_btn.style.display = 'inline-block';
    menu_btn.style.display = 'none';
})

// close functioon

const closeNav = () => {
    menu.style.display = 'none';
    close_btn.style.display = 'none';
    menu_btn.style.display = 'inline-block';
}

close_btn.addEventListener('click',closeNav)

//==============================================

let words = document.querySelectorAll(".word");
words.forEach((word) =>{
    let letters = word.textContent.split("");
    word.textContent = "";
    letters.forEach((letter) =>{
        let span = document.createElement("span");
        span.textContent = letter;
        span.className = "letter";
        word.append(span);
    });
});

let currentWordIndex = 0;
let maxWordIndex = words.length -1;
words[currentWordIndex].style.opacity = "1";

let changeText = ()=>{
    let currentWord = words[currentWordIndex];
    let nextWord = currentWordIndex === maxWordIndex ? words[0] : words[currentWordIndex +1];
    Array.from(currentWord.children).forEach((letter,i)=>{
        setTimeout(()=>{
            letter.className = "letter out";
        },i*80);
    });

    nextWord.style.opacity = "1";
    Array.from(nextWord.children).forEach((letter,i)=>{
        letter.className = "letter behind";
        setTimeout(()=>{
            letter.className ="letter in";
        },340 + i * 80)
    });

    currentWordIndex = currentWordIndex === maxWordIndex ? 0 : currentWordIndex + 1;
};

changeText();
setInterval(changeText,3000);



//skills animation

//number1 Team Work

let number1 = document.getElementById("number1");
let counter1 = 0;

setInterval(() =>{

    if(counter1 == 95){
        clearInterval();
    }else{
        counter1 += 1;
    number1.innerHTML = counter1 + "%";
    }
},20)

// number2 Creativity

let number2 = document.getElementById("number2");
let counter2 = 0;

setInterval(() =>{

    if(counter2 == 80){
        clearInterval();
    }else{
        counter2 += 1;
    number2.innerHTML = counter2 + "%";
    }
},20)

// number3 Project Managment

let number3 = document.getElementById("number3");
let counter3 = 0;

setInterval(() =>{

    if(counter3 == 65){
        clearInterval();
    }else{
        counter3 += 1;
    number3.innerHTML = counter3 + "%";
    }
},20)

// number4 Communication

let number4 = document.getElementById("number4");
let counter4 = 0;

setInterval(() =>{
 
    if(counter4 == 75){
        clearInterval();
    }else{
        counter4 += 1;
    number4.innerHTML = counter4 + "%";
    }
},20)

//==============================================


function post_a(){
    document.getElementById('post1').click();
}

function post_b(){
    document.getElementById('post2').click();
    const element = document.getElementById('pp');
    element.removeChild();
}

function sendemail(){
    Email.send({
        Host : "smtp.elasticemail.com",
        Username : "abdullahiasad777@hotmail.com",
        Password : "password",
        To : 'abdullahiasad777@hotmail.com',
        From : document.getElementById("email").value,
        Subject : "New requirment from client",
        Body : "And this is the body"
    }).then(
      message => alert(message)
    );
}

